// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:19 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs043/cs043_1/main.cs
 * url:  cs/cs043/cs043_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:19 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs43.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		string[] str = {
			"Kitty on your lap" ,
			"Silver Gene" ,
			"Di Gi Charat" ,
			"Tokyo mew mew"
		};

		foreach(string tmp in str)
			System.Console.WriteLine(tmp);
	}
}
