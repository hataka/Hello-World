// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:03 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs006/cs006_1/main.cs
 * url:  cs/cs006/cs006_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:03 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs6.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int i = 10;

		i++;
		System.Console.WriteLine(i);
		++i;
		System.Console.WriteLine(i);
	}
}
