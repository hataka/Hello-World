// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:05 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs009/cs009_4/main.cs
 * url:  cs/cs009/cs009_4/main.cs
 * created: Time-stamp: <2016-10-03 06:15:05 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs9.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int x = 100;
		System.Console.WriteLine((x  < 200) & (x > 50));
		System.Console.WriteLine((x == 50) | (x == 200));
	}
}
