// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:11 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs023/cs023_1/main.cs
 * url:  cs/cs023/cs023_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:11 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs23.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		string str1 = "Kitty on your lap";
		{
			string str2 = "Tokyo mew mew";
			System.Console.WriteLine(str1);
			System.Console.WriteLine(str2);
		}
		System.Console.WriteLine(str1);
		//System.Console.WriteLine(str2); //エラー
	}
}
