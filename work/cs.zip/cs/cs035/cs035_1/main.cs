// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:16 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs035/cs035_1/main.cs
 * url:  cs/cs035/cs035_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:16 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs35.html
 * description: 
 *
 *================================================================*/
class Test {
	public static void Main() {
		string[] str = new string[3];
		str[0] = "Kitty on your lap";
		str[1] = "Silver Gene";
		str[2] = "Nekoneko Zoo";

		for (int i = 0 ; i  < 3 ; i++)
			System.Console.WriteLine(str[i]);
	}
}
