// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:05 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs010/cs010_1/main.cs
 * url:  cs/cs010/cs010_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:05 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs10.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		ushort us = 0xA5FF;
		byte sb = (byte)us;

		System.Console.WriteLine("ushort = " + us);
		System.Console.WriteLine("byte = " + sb);
	}
}
