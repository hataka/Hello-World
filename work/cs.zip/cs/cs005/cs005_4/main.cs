// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:03 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs005/cs005_4/main.cs
 * url:  cs/cs005/cs005_4/main.cs
 * created: Time-stamp: <2016-10-03 06:15:03 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs5.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int var1 , var2 , var3;
		var1 = var2 = var3 = 100;

		System.Console.WriteLine("var1 = " + var1);
		System.Console.WriteLine("var2 = " + var2);
		System.Console.WriteLine("var3 = " + var3);
	}
}
