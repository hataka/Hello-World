// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:16 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs036/cs036_1/main.cs
 * url:  cs/cs036/cs036_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:16 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs36.html
 * description: 
 *
 *================================================================*/
class Test {
	public static void Main() {
		string[] str = {
			"Kitty on your lap",
			"Silver Gene",
			"Nekoneko Zoo"
		};
		for (int i = 0 ; i  < str.Length ; i++)
			System.Console.WriteLine(str[i]);
	}
}
