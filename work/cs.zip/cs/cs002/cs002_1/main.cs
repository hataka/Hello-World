// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:36 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs002/cs002_1/main.cs
 * url:  cs/cs002/cs002_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:36 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs2_7.html
 * description: 
 *
 *================================================================*/
partial class Test {
	static void Main() {
		System.Console.WriteLine(new Test());
	}
}

partial class Test {
	public override string  ToString() {
		return "Test : ふるふるふるむーーーーん";
	}
}
