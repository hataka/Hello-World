// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:09 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs019/cs019_3/main.cs
 * url:  cs/cs019/cs019_3/main.cs
 * created: Time-stamp: <2016-10-03 06:15:09 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs19.html
 * description: 
 *
 *================================================================*/
class Kitty {
	static Kitty() {
		System.Console.WriteLine("Kitty on your lap");
	}
	public static void Temp() {}
}

class Test {
	static void Main() {
		Kitty.Temp();
	}
}
