// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:06 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs012/cs012_1/main.cs
 * url:  cs/cs012/cs012_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:06 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs12.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int msg = 1;
		switch(msg) {
		case 0:
			System.Console.WriteLine("Di Gi Charat");
			break;
		case 1:
			System.Console.WriteLine("Kitty on your lap");
			break;
		case 2:
			System.Console.WriteLine("Tokyo mew mew");
			break;
		default:
			System.Console.WriteLine("Nekoneko Zoo");
			break;
		}
	}
}
