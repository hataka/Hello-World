// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:06 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs012/cs012_3/main.cs
 * url:  cs/cs012/cs012_3/main.cs
 * created: Time-stamp: <2016-10-03 06:15:06 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs12.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		string str = "Di Gi Charat";
		switch(str) {
		case "Tokyo mew mew":
			System.Console.WriteLine("ご奉仕するニャン");
			break;
		case "Di Gi Charat":
			System.Console.WriteLine("目からビーーーム！");
			break;
		default:
			System.Console.WriteLine("Kitty on your lap");
			break;
		}
	}
}
