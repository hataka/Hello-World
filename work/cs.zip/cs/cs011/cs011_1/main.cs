// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:06 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs011/cs011_1/main.cs
 * url:  cs/cs011/cs011_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:06 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs11.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int x = 10;
		if (x  <= 100) System.Console.WriteLine("Kitty on your lap");
		if (x > 100) System.Console.WriteLine("Tokyo mew mew");
	}
}
