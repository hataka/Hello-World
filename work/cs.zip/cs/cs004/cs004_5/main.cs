// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:02 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs004/cs004_5/main.cs
 * url:  cs/cs004/cs004_5/main.cs
 * created: Time-stamp: <2016-10-03 06:15:02 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs4.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		byte var1 = 255;
		short var2 = 32767;
		uint var3 = 4294967295;

		System.Console.WriteLine(var1);
		System.Console.WriteLine(var2);
		System.Console.WriteLine(var3);
	}
}
