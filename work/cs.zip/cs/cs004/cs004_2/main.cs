// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:02 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs004/cs004_2/main.cs
 * url:  cs/cs004/cs004_2/main.cs
 * created: Time-stamp: <2016-10-03 06:15:02 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs4.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		string str;

		str = "Kitty on your lap";
		System.Console.WriteLine(str);
		str = "Tokyo mew mew";
		System.Console.WriteLine(str);
	}
}
