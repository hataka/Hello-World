// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:03 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs004/cs004_8/main.cs
 * url:  cs/cs004/cs004_8/main.cs
 * created: Time-stamp: <2016-10-03 06:15:03 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs4.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int var = 100;
		System.Console.WriteLine(-10);
		System.Console.WriteLine(-var);

		var = -1000;
		System.Console.WriteLine(-var);
	}
}
