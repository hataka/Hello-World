// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:02 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs004/cs004_1/main.cs
 * url:  cs/cs004/cs004_1/main.cs
 * created: Time-stamp: <2016-10-03 06:15:02 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs4.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		int i;
		double d;
		string str;

		i = 1024;
		d = 0.015;
		str = "Kitty on your lap";

		System.Console.WriteLine(i);
		System.Console.WriteLine(d);
		System.Console.WriteLine(str);
	}
}
