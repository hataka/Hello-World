// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:02 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs003/cs003_2/main.cs
 * url:  cs/cs003/cs003_2/main.cs
 * created: Time-stamp: <2016-10-03 06:15:02 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs3.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		System.Console.WriteLine(42.195);
		System.Console.WriteLine(0.3e-2);		
	}
}
