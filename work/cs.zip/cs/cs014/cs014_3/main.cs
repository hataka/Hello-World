// -*- mode: java -*-  Time-stamp: <2016-10-03 06:15:07 kahata>
/*================================================================
 * title: 
 * file: 
 * path; cs/cs014/cs014_3/main.cs
 * url:  cs/cs014/cs014_3/main.cs
 * created: Time-stamp: <2016-10-03 06:15:07 kahata>
 * revision: $Id$
 * Programmed By: kahata
 * To compile:
 * To run: 
 * link: http://wisdom.sakura.ne.jp/
 * link: http://wisdom.sakura.ne.jp/programming/cs/cs14.html
 * description: 
 *
 *================================================================*/
class Test {
	static void Main() {
		for (int x = 100 , y = 0 ; x != y ; x-- , y++)
			System.Console.WriteLine("x = " + x + " : y = " + y);
	}
}
